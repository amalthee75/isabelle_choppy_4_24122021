    <footer>
        <h5>&copy; 2023 by Iris Isis</h5>
        <div class="social-media">
            <a href="https://www.youtube.com"><i class="fa-brands fa-youtube fa-2x"></i></a>
            <a href="https://www.facebook.com/" class="reseau"><i class="fa-brands fa-facebook fa-2x"></i></a>
            <a href="https://www.twitter.com" class="reseau"><i class="fa-brands fa-square-twitter fa-2x"></i></a>
            <a href="https://www.instagram.com" class="reseau"><i class="fa-brands fa-square-instagram fa-2x"></i></a>
            <a href="https://www.telegram.com" class="reseau"><i class="fa-brands fa-telegram fa-2x"></i></a>
        </div>
    </footer>