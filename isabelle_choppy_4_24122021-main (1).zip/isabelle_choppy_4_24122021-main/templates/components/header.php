<header>
    <h1>Blog - Jean Forcheroche</h1>
    <div class="onglets">
        <a href="http://localhost/mvc-site/index.php">Accueil</a>
        <a href="http://localhost/mvc-site/index.php?action=login">Connexion</a>

    </div>
</header>




<!-- <div id="message">
    <?php //include('./templates/components/message.php');
    ?>
</div> -->