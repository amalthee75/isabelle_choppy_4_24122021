 <header>
     <h1>Jean Forcheroche Blog</h1>
     <div class="onglets">
         <a href="http://localhost/mvc-site/index.php">HOME</a>
         <a href="http://localhost/mvc-site/index.php?action=dashboard">TABLEAU DE BORD</a>
         <a href="http://localhost/mvc-site/index.php?action=showFormPost">AJOUTER UN POST</a>
         <a href="http://localhost/mvc-site/index.php?action=show_Comments">COMMENTAIRES</a>

     </div>
 </header>

 <div id="message">
     <?php include('./templates/components/message.php');
        ?>
 </div>